# Dark Space Theme
##### v1.1.0

![preview](https://addons.cdn.mozilla.net/user-media/version-previews/full/2911/2911625.svg)

[Firefox Addon](https://addons.mozilla.org/en-US/firefox/addon/nicothin-space/?utm_content=repo&utm_medium=referral&utm_source=github.com)
Simple dark theme with dynamic background.

Based on video 'Animation of Stars' released by Vimeo under Creative Commons (CC0) license. 
